package com.example.grocery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
@RequestMapping("/api/grocery-items")
public class GroceryItemController {
    
    @Autowired
    private GroceryItemService groceryItemService;  // Corrected variable name

    @GetMapping
    public List<GroceryItem> getAllItems() {
        return groceryItemService.getAllItems();
    }

    @GetMapping("/{id}")
    public ResponseEntity<GroceryItem> getItemById(@PathVariable Long id) {
        GroceryItem item = groceryItemService.getItemById(id);
        return item != null ? ResponseEntity.ok(item) : ResponseEntity.notFound().build(); // Handle item not found
    }

    @PostMapping
    public GroceryItem addItem(@RequestBody GroceryItem item) {
        return groceryItemService.addItem(item);
    }

    @PutMapping("/{id}")
    public ResponseEntity<GroceryItem> updateItem(@PathVariable Long id, @RequestBody GroceryItem itemDetails) {
        GroceryItem updatedItem = groceryItemService.updateItem(id, itemDetails);
        return ResponseEntity.ok(updatedItem); // Return updated item
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable Long id) {
        groceryItemService.deleteItem(id);
        return ResponseEntity.noContent().build();
    }
}
